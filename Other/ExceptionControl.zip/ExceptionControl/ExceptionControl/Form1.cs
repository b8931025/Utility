﻿using System;
using System.Windows.Forms;
using System.Threading;
using System.Net.Http;
using System.Net;
using System.Linq;
namespace ExceptionControl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //UI錯誤可以被try catch抓住，如果不抓住就會丟給Application
            throw new Exception("UI錯誤");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //非UI錯誤無法被try catch抓住，一律丟給Application的UnhandledException
            (new Thread(ThreadException)).Start("T1");
        }
        public static void ThreadException(object obj)
        {
            throw new Exception("非UI錯誤");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            HttpResponseMessage result = getHrm();
        }

        public static HttpResponseMessage getHrm()
        {
            HttpResponseMessage hrm = null;
            using (var hc = new HttpClient())
            {
                string sUri = "error url";//用一個不存在的api
                hc.BaseAddress = new Uri("https://localhost/");
                //hrm = hc.GetAsync(sUri).Result; //UI Exception:AggregateException 發生一項或多項錯誤 
                hrm = PerformActionSafe(() => (hc.GetAsync(sUri).Result));//將AggregateException抓住，解析InnerException，回覆HttpResponseMessage

                if ((int)hrm.StatusCode > 299)
                {
                    var result = hrm.Content.ReadAsStringAsync().Result;
                    throw new Exception($"Error:{result} ,Status Code:{hrm.StatusCode.ToString()}");
                }
            }

            return hrm;
        }

        public static HttpResponseMessage PerformActionSafe(Func<HttpResponseMessage> action)
        {
            try
            {
                return action();
            }
            catch (AggregateException aex)//發生一項或多項錯誤
            {
                Exception firstException = null;
                if (aex.InnerExceptions != null && aex.InnerExceptions.Any())
                {
                    firstException = aex.InnerExceptions.First();

                    if (firstException.InnerException != null)
                        firstException = firstException.InnerException;
                }

                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent(firstException != null
                                            ? firstException.ToString()
                                            : "Encountered an AggreggateException without any inner exceptions")
                };

                return response;
            }
        }
    }
}
