﻿using System;
using System.Windows.Forms;
using System.Threading;

namespace ExceptionControl
{
    static class Program
    {
        /// <summary>
        /// 應用程式的主要進入點。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            //設定UnhandledExceptionMode.CatchException時，就會把UI Exception丟到ThreadException
            //設定UnhandledExceptionMode.ThrowException時，UI Exception不會丟到ThreadException，而會丟到UnhandledException這邊來 
            //PS:通通丟給UnhandledException就不用寫兩個function，但是app會強制關閉
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            //這邊會設定UI Exception的接收函式
            Application.ThreadException += new ThreadExceptionEventHandler(OnThreadException);
            //非UI Exception一定會丟給UnhandledException
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(OnUnhandledException);
            Application.Run(new Form1());
        }

        static void OnThreadException(object sender, ThreadExceptionEventArgs e)
        {
            MessageBox.Show($"UI exception was occurred :{e.Exception.Message}");
        }

        static void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            //非UI Exception一定會丟給UnhandledException
            MessageBox.Show($"unhandled exception was occurred :{(e.ExceptionObject as Exception).Message}");
            //UnhandledException發生後，CLR 會自動將程式結束，跳出結束方塊，如果不要跳出方塊，可以直接用這行結束
            Environment.Exit(1);
        }
    }
}
